package com.example.mehdi.myfirstgame;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

public class CharacterSprite implements SensorEventListener {

    private SensorManager sensorManager;

    private Bitmap image;
    private int xVelocity = 10;
    private int yVelocity = 10;
    private int x = 50;
    private int y;
    private int screenWidth = Resources.getSystem().getDisplayMetrics().widthPixels;
    private int screenHeight = Resources.getSystem().getDisplayMetrics().heightPixels;

    public CharacterSprite(Bitmap bmp, Context context) {
        this.image = bmp;
        sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
    }

    public void draw(Canvas canvas) {
        image = Bitmap.createScaledBitmap(image ,250, 250, false);
        canvas.drawBitmap(image, x, y, null);
    }

    public void update() {
        sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);
        //this.x += xVelocity;
        this.y += yVelocity;

        if (x > screenWidth - image.getWidth()) {
            x = screenWidth - image.getWidth();
        }

        if (x<0) {
            x=0;
        }

        if ( y > screenHeight - image.getHeight() - 70) {
            y = screenHeight - image.getHeight() - 70;
        }

        if (y < 0) {
            y = 0;
        }
    }

    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType()==Sensor.TYPE_ACCELEROMETER) {
            //xVelocity = - (int) event.values[0]*2;
            yVelocity = (int) event.values[1]*2;
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
