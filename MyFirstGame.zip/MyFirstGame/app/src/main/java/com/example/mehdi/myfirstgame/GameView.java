package com.example.mehdi.myfirstgame;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.MediaPlayer;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.util.Log;
import android.view.SurfaceView;
import android.view.SurfaceHolder;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import static java.lang.Thread.sleep;

public class GameView extends SurfaceView implements SurfaceHolder.Callback {

    private static final String TAG = GameView.class.getSimpleName();

    private MainThread thread;
    private CharacterSprite characterSprite;
    private Pipe pipe1;
    private Pipe pipe2;
    private MovingBackground leftBackground;
    private MovingBackground rightBackground;

    private ArrayList<Pipe> pipeList = new ArrayList<>();
    private ArrayList<MovingBackground> backgroundsList = new ArrayList<>();

    private Context context;

    private Random r = new Random();

    private int minPipeHeight = 200;
    private int screenWidth = Resources.getSystem().getDisplayMetrics().widthPixels;
    private int screenHeight = Resources.getSystem().getDisplayMetrics().heightPixels;

    private MediaPlayer mp;
    private AudioTrack mAudioTrack;
    private int outputBufferSize;

    private int score;

    public GameView(Context context) {
        super(context);
        this.context = context;

        getHolder().addCallback(this);
        thread = new MainThread(getHolder(), this);
        setFocusable(true);

        mp = MediaPlayer.create(getContext(), R.raw.wow);

        this.score = 0;

        outputBufferSize = AudioTrack.getMinBufferSize(16000,
                AudioFormat.CHANNEL_IN_STEREO,
                AudioFormat.ENCODING_PCM_16BIT);

    }

    //
    public void update() {
        characterSprite.update();

        pipe1.update();
        pipe2.update();

        leftBackground.update();
        rightBackground.update();

        long startTime = System.nanoTime();
        logic();
        long endTime = System.nanoTime();
        long duration = (endTime-startTime);

         //duration à peu près 20~25 000

        Log.d(TAG, "durée de Logic = " + duration);
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);
        if(canvas!=null){
            canvas.drawColor(Color.RED);
            //this.background = BitmapFactory.decodeResource(getResources(), R.drawable.donald_fuck_yeah);
            //this.background = Bitmap.createScaledBitmap(this.background ,screenWidth, screenHeight, false);
            //canvas.drawBitmap(this.background, 0, 0, null);

            leftBackground.draw(canvas);
            rightBackground.draw(canvas);

            Paint paint = new Paint();
            paint.setColor(Color.WHITE);
            paint.setTextSize(60);
            canvas.drawText("score : "+this.score, screenWidth/2-150, 60, paint);

            drawCharacter(canvas);

            pipe1.draw(canvas);
            pipe2.draw(canvas);

        }
    }

    private void drawCharacter(Canvas canvas) {
        characterSprite.draw(canvas);
    }

    private void putGameAtStatingPlace() {

        try {
            sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        pipe1.setX(screenWidth);
        pipe2.setX(screenWidth+screenWidth/2);
        characterSprite.setY(screenHeight/2-(125));
        //leftBackground.setX(0);
        //rightBackground.setX(screenWidth);
        score = 0;
    }

    private void logic() {
        //boolean doOnceScore = false;

        for(int i = 0; i < pipeList.size(); i++) {
            if (this.score == 20) {
                pipeList.get(i).setxVelocity(-15);
            }
            //detect collision with bitmap (which is a square of 250 by 250)
            if((characterSprite.getX()+250) == pipeList.get(i).getX() ) { //&&  characterSprite.getX()+250 <= (pipeList.get(i).getX()+50) ) {//characterSprite.getY() <= pipeList.get(i).getySize() && characterSprite.getY() >= (pipeList.get(i).getySize()+pipeList.get(i).getGate()) ) { //&& characterSprite.getX()+250 >= pipeList.get(i).getX() &&  characterSprite.getX()+250 <= (pipeList.get(i).getX()+50)
                //Log.d(TAG, "position X de Trump = " + (characterSprite.getX()+250) + " position X pipe = " + pipeList.get(i).getX());
                if (characterSprite.getY() <= pipeList.get(i).getySize() || (characterSprite.getY()+250) >= (pipeList.get(i).getySize() + pipeList.get(i).getGate())) {
                    //mp.start();

                    putGameAtStatingPlace();
                } else { //(characterSprite.getY() > pipeList.get(i).getySize() && (characterSprite.getY()+250) < (pipeList.get(i).getySize() + pipeList.get(i).getGate()) && !doOnceScore)
                    this.score++;
                    //doOnceScore=true;
                    //Log.d(TAG, "le scoreTrump est : " +  this.score);
                }
            }

            //redraw the pipe with random v height and gate everytime it's out of the screen
            if(pipeList.get(i).getX() < -100) {
                pipeList.get(i).setX(screenWidth);
                pipeList.get(i).setySize(r.nextInt((screenHeight/2-this.minPipeHeight)+1)+this.minPipeHeight);
                pipeList.get(i).setGate(r.nextInt((900-500)+1)+500);
            }
        }

        for(int j = 0; j < backgroundsList.size(); j++) {
            if(backgroundsList.get(j).getX() < - screenWidth) {
                backgroundsList.get(j).setX(screenWidth-20);
            }
        }

    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        thread.setRunning(true);
        thread.start();

        characterSprite = new CharacterSprite(BitmapFactory.decodeResource(getResources(), R.drawable.donald), this.context);

        pipe1 = new Pipe(screenWidth, 50, r.nextInt((screenHeight/2-this.minPipeHeight)+1)+this.minPipeHeight, r.nextInt((900-500)+1)+500);
        pipe2 = new Pipe(screenWidth + screenWidth/2 + 50, 50, r.nextInt((screenHeight/2-this.minPipeHeight)+1)+this.minPipeHeight, r.nextInt((900-500)+1)+500);
        pipeList.add(pipe1);
        pipeList.add(pipe2);


        leftBackground = new MovingBackground(BitmapFactory.decodeResource(getResources(), R.drawable.image_back_gauche), 0);
        leftBackground.setImageScale(Bitmap.createScaledBitmap(leftBackground.getImage() , screenWidth, screenHeight, false));
        rightBackground = new MovingBackground(BitmapFactory.decodeResource(getResources(), R.drawable.image_back_droite), screenWidth);
        rightBackground.setImageScale(Bitmap.createScaledBitmap(rightBackground.getImage() , screenWidth, screenHeight, false));
        leftBackground.setX(0);
        rightBackground.setX(screenWidth);
        backgroundsList.add(leftBackground);
        backgroundsList.add(rightBackground);

    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        boolean retry = true;
        while (retry) {
            try {
                thread.setRunning(false);
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            retry = false;
        }
    }
}
