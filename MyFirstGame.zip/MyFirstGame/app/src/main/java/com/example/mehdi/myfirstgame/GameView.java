package com.example.mehdi.myfirstgame;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.util.Log;
import android.view.SurfaceView;
import android.view.SurfaceHolder;

import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class GameView extends SurfaceView implements SurfaceHolder.Callback {

    private static final String TAG = GameView.class.getSimpleName();

    private MainThread thread;
    private CharacterSprite characterSprite;
    private Pipe pipe1;
    private Pipe pipe2;

    private ArrayList<Pipe> pipeList = new ArrayList<>();

    private Context context;

    private Random r = new Random();

    private int minPipeHeight = 200;
    private int screenWidth = Resources.getSystem().getDisplayMetrics().widthPixels;
    private int screenHeight = Resources.getSystem().getDisplayMetrics().heightPixels;

    public GameView(Context context) {
        super(context);
        this.context = context;

        getHolder().addCallback(this);
        thread = new MainThread(getHolder(), this);
        setFocusable(true);

    }

    //added Canvas parameter to draw the pipes.... NEED to change this, does not work
    public void update() {
        characterSprite.update();

        pipe1.update();
        pipe2.update();

        logic();
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);
        if(canvas!=null){
            canvas.drawColor(Color.BLACK);
            drawCharacter(canvas);

            pipe1.draw(canvas);
            pipe2.draw(canvas);
            //drawPipe(canvas, 0);
        }
    }

    private void drawCharacter(Canvas canvas) {
        characterSprite.draw(canvas);
    }

    private void drawPipe(Canvas canvas, int i) {
        pipeList.get(i).draw(canvas);
    }

    private void logic() {

        pipeList.add(pipe1);
        pipeList.add(pipe2);

        for(int i = 0; i < pipeList.size(); i++) {

            //detect collision with bitmap (which is a square)
            //TODO : that shit does not work, Log everything and understand wtf is happening
            if(characterSprite.getY() <= pipeList.get(i).getySize() && characterSprite.getY() >= (pipeList.get(i).getySize()+pipeList.get(i).getGate()) ) { //&& characterSprite.getX()+250 >= pipeList.get(i).getX() &&  characterSprite.getX()+250 <= (pipeList.get(i).getX()+50)
                Log.d(TAG, "TOUCHEYYYY");
            }

            //redraw the pipe with random v height and gate everytime it's out of the screen
            if(pipeList.get(i).getX() < 0) {
                pipeList.get(i).setX(screenWidth);
                pipeList.get(i).setySize(r.nextInt((screenHeight/2-this.minPipeHeight)+1)+this.minPipeHeight);
                pipeList.get(i).setGate(r.nextInt((900-500)+1)+500);
            }
        }
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        thread.setRunning(true);
        thread.start();
        characterSprite = new CharacterSprite(BitmapFactory.decodeResource(getResources(), R.drawable.donald), this.context);
        //pipeList.add(new Pipe());
        pipe1 = new Pipe(screenWidth, 50, r.nextInt((screenHeight/2-this.minPipeHeight)+1)+this.minPipeHeight, r.nextInt((900-500)+1)+500);
        pipe2 = new Pipe(screenWidth + screenWidth/2, 50, r.nextInt((screenHeight/2-this.minPipeHeight)+1)+this.minPipeHeight, r.nextInt((900-500)+1)+500);
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        /**
        boolean retry = true;
        while (retry) {
            try {
                thread.setRunning(false);
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            retry = false;
        }
         */
    }
}
