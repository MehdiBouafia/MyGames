package com.example.mehdi.myfirstgame;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;

public class MovingBackground {

    private Bitmap image;
    private int xVelocity = -10;
    private int x;
    private int screenWidth = Resources.getSystem().getDisplayMetrics().widthPixels;
    private int screenHeight = Resources.getSystem().getDisplayMetrics().heightPixels;

    public MovingBackground(Bitmap bmp, int x) {
        this.image = bmp;
        this.x = x;
    }

    public void draw(Canvas canvas) {
        //image = Bitmap.createScaledBitmap(image , screenWidth, screenHeight, false);
        canvas.drawBitmap(image, x, 0, null);
    }

    public void update() {
        this.x += xVelocity;
    }

    public int getX() {
        return this.x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public Bitmap getImage() {
        return this.image;
    }

    public void setImageScale(Bitmap image) {
        this.image = image;
    }

}
