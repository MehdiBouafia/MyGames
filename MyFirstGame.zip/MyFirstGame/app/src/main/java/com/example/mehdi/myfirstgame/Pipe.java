package com.example.mehdi.myfirstgame;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.util.Log;

import java.util.Random;

public class Pipe {


    private static final String TAG = Pipe.class.getSimpleName();
    private int xVelocity = -10;
    private int x;
    private int y;

    private int gate;

    private Random r = new Random();

    private int xSize;
    private int ySize;

    private int screenWidth = Resources.getSystem().getDisplayMetrics().widthPixels;
    private int screenHeight = Resources.getSystem().getDisplayMetrics().heightPixels;

    public Pipe(int x, int xSize, int ySize, int gate) {
        this.x = x; //screenWidth;
        this.y = 0;
        this.xSize = xSize;
        this.ySize = ySize;
        this.gate = gate; //
        Log.d(TAG, String.valueOf(ySize) + " -- " + gate);
    }

    public void draw(Canvas canvas) {
        Paint paint = new Paint();
        paint.setColor(Color.WHITE);
        canvas.drawRect(this.x, 0, this.x+100, this.ySize, paint);
        canvas.drawRect(this.x, this.ySize + this.gate, this.x+100, this.screenHeight, paint);
    }

    public void update() {
        this.x += xVelocity;
    }

    public int getX() {
        return this.x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getySize() {
        return this.ySize;
    }

    public int getGate() {
        return this.gate;
    }

    public void setySize(int ySize) {
        this.ySize = ySize;
    }

    public void setGate(int gate) {
        this.gate = gate;
    }

}
