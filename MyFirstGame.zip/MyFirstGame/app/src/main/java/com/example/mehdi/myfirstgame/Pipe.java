package com.example.mehdi.myfirstgame;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.Rect;


public class Pipe {


    private static final String TAG = Pipe.class.getSimpleName();
    private int xVelocity = -12;
    private int x;
    private int y;

    private int gate;

    private int xSize;
    private int ySize;

    private int screenWidth = Resources.getSystem().getDisplayMetrics().widthPixels;
    private int screenHeight = Resources.getSystem().getDisplayMetrics().heightPixels;

    private Rect pipe1;
    private Rect pipe2;

    public Pipe(int x, int xSize, int ySize, int gate) {
        this.x = x; //screenWidth;
        this.y = 0;
        this.xSize = xSize;
        this.ySize = ySize;
        this.gate = gate;
        pipe1 = new Rect(this.x, 0, this.x+100, this.ySize);
        pipe2 = new Rect(this.x, this.ySize + this.gate, this.x+100, this.screenHeight);
    }

    public void draw(Canvas canvas) {
        Paint paint = new Paint();
        paint.setColor(Color.YELLOW);
        //canvas.drawRect(pipe1, paint);
        //canvas.drawRect(pipe2, paint);
        canvas.drawRect(this.x, 0, this.x+100, this.ySize, paint);
        canvas.drawRect(this.x, this.ySize + this.gate, this.x+100, this.screenHeight, paint);
    }

    public void update() {
        this.x += xVelocity;
    }

    public int getX() {
        return this.x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getySize() {
        return this.ySize;
    }

    public int getGate() {
        return this.gate;
    }

    public void setySize(int ySize) {
        this.ySize = ySize;
    }

    public void setGate(int gate) {
        this.gate = gate;
    }

    public void setxVelocity(int velocity) {
        this.xVelocity = velocity;
    }

}
